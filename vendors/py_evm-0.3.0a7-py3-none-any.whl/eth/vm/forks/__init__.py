from .tangerine_whistle import (  # noqa: F401
    TangerineWhistleVM,
)
from .frontier import (  # noqa: F401
    FrontierVM,
)
from .homestead import (  # noqa: F401
    HomesteadVM,
)
from .spurious_dragon import (  # noqa: F401
    SpuriousDragonVM,
)
from .byzantium import (  # noqa: F401
    ByzantiumVM,
)
from .constantinople import (  # noqa: F401
    ConstantinopleVM,
)
from .petersburg import (  # noqa: F401
    PetersburgVM,
)
from .istanbul import (  # noqa: F401
    IstanbulVM,
)
