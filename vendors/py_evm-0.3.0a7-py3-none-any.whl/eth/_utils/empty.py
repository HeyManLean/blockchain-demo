class Empty(object):
    pass


empty = Empty()
